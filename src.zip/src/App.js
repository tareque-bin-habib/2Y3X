import React from 'react';
import HomePage from './pages/HomePage/HomePage';


const App = () => {
  return (
    <div>
      <HomePage></HomePage>
    </div>
  );
};

export default App;